var counter = 1
        
        
        while counter !- 0
        {
                        
        }
        
        
        
        
        
        
        
        
    